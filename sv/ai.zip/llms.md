# inera.core.template#2.3.0: Inera FHIR Implementation Guide Template(sv)

## Pages

* [Hem](index.md)
* [REST-interaktioner och sökparametrar](rest-interactions.md)
* [Mappning till profiler](mappings.md)
* [Inledning](introduction.md)
* [Användningsfall](use-cases.md)
* [Nedladdningar](downloads.md)
* [Sammanfattning av artefakter](artifacts.md)
* [Säkerhet och behörighet](security.md)
* [CapabilityStatement](capabilitystatement.md)
* [Informationsunderlag](information-basis.md)
* [Roller och ansvar](roles-and-responsibilities.md)
* [Förväntade svar](expected-responses.md)
* [Testning och validering](testing.md)
* [Felhantering](error-handling.md)
* [Om](about.md)
* [Versionshistorik](version-history.md)

## Resources

### Resource Profiles

* [Inera Patient](StructureDefinition-IneraPatient.md)

### ImplementationGuides

* [Inera FHIR Implementation Guide Template](ImplementationGuide-inera.core.template.md)

### Examples

* [IneraPatientExample (Patient)](Patient-IneraPatientExample.md)
