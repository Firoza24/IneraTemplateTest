# inera.core.template#2.3.0: Inera FHIR Implementation Guide Template(sv)

## Pages

* [Hem](index.md)
* [Säkerhet och behörighet](security.md)
* [Roller och ansvar](roles-and-responsibilities.md)
* [Användningsfall](use-cases.md)
* [Förväntade svar](expected-responses.md)
* [Versionshistorik](version-history.md)
* [Informationsunderlag](information-basis.md)
* [Om](about.md)
* [CapabilityStatement](capabilitystatement.md)
* [Testning och validering](testing.md)
* [Sammanfattning av artefakter](artifacts.md)
* [Inledning](introduction.md)
* [Nedladdningar](downloads.md)
* [Felhantering](error-handling.md)
* [Mappning till profiler](mappings.md)
* [REST-interaktioner och sökparametrar](rest-interactions.md)

## Resources

### Resource Profiles

* [Inera Patient](StructureDefinition-IneraPatient.md)

### ImplementationGuides

* [Inera FHIR Implementation Guide Template](ImplementationGuide-inera.core.template.md)

### Examples

* [IneraPatientExample (Patient)](Patient-IneraPatientExample.md)
